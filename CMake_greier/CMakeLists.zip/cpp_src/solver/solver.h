#ifndef SOLVER_H
#define SOLVER_H
// definer solver klassen
#endif
