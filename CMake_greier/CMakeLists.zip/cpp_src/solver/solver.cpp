#include "solver.h"
// definer solver klassen

